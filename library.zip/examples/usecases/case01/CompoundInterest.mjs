const definitionMetadata = globalThis.Symbol.for("mlscript.definitionMetadata");
const prettyPrint = globalThis.Symbol.for("mlscript.prettyPrint");
import runtime from "file:///c:/Users/ytoh9/.vscode/extensions/mlscript-studio.mlscript-studio-0.7.1/runtime/std/Runtime.mjs";
import Studio from "file:///c:/Users/ytoh9/OneDrive/%EB%B0%94%ED%83%95%20%ED%99%94%EB%A9%B4/mlscropt%200.7.1/library/Studio.mjs";
import Render from "file:///c:/Users/ytoh9/OneDrive/%EB%B0%94%ED%83%95%20%ED%99%94%EB%A9%B4/mlscropt%200.7.1/library/Render.mjs";
let CompoundInterest1, lambda, lambda$;
lambda$ = (undefined, function (CompoundInterest2) {
  return (t) => {
    return lambda(CompoundInterest2, t)
  }
});
lambda = (undefined, function (CompoundInterest2, t) {
  let tmp, p, c, inlinedVal, tmp1, inlinedVal1, p1, c1, r, inlinedVal2, p2, c2, r1, inlinedVal3, p3, c3, r2, inlinedVal4, p4, c4, r3, inlinedVal5, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, inlinedVal6, inlinedVal7, inlinedVal8, inlinedVal9, inlinedVal10, inlinedVal11, inlinedVal12, inlinedVal13, inlinedVal14, inlinedVal15, inlinedVal16, inlinedVal17, tmp22, tmp23, tmp24, tmp25, tmp26, scrut, tmp27, tmp28, tmp29, tmp30, scrut1, tmp31, tmp32, tmp33, tmp34, tmp35, tmp36, tmp37, tmp38, tmp39;
  p = CompoundInterest2.principal;
  c = CompoundInterest2.monthlyContribution;
  inlinedVal1 = CompoundInterest2.monthsPerYear * t;
  tmp1 = c * inlinedVal1;
  inlinedVal = p + tmp1;
  p1 = CompoundInterest2.principal;
  c1 = CompoundInterest2.monthlyContribution;
  r = CompoundInterest2.annualRate;
  tmp17 = r * t;
  tmp18 = 1 + tmp17;
  tmp19 = p1 * tmp18;
  inlinedVal6 = CompoundInterest2.monthsPerYear * t;
  tmp20 = c1 * inlinedVal6;
  tmp21 = tmp19 + tmp20;
  inlinedVal7 = CompoundInterest2.monthsPerYear * t;
  tmp35 = r / CompoundInterest2.monthsPerYear;
  tmp36 = c1 * tmp35;
  tmp37 = tmp36 * inlinedVal7;
  tmp38 = inlinedVal7 - 1;
  tmp39 = tmp37 * tmp38;
  inlinedVal8 = tmp39 / 2;
  inlinedVal2 = tmp21 + inlinedVal8;
  p2 = CompoundInterest2.principal;
  c2 = CompoundInterest2.monthlyContribution;
  r1 = CompoundInterest2.annualRate;
  tmp12 = r1 / CompoundInterest2.monthsPerYear;
  tmp13 = 1 + tmp12;
  inlinedVal9 = CompoundInterest2.monthsPerYear * t;
  tmp14 = runtime.safeCall(globalThis.Math.pow(tmp13, inlinedVal9));
  tmp15 = p2 * tmp14;
  tmp16 = r1 / CompoundInterest2.monthsPerYear;
  inlinedVal10 = CompoundInterest2.monthsPerYear * t;
  scrut1 = tmp16 == 0;
  if (scrut1 === true) {
    inlinedVal11 = c2 * inlinedVal10;
  } else {
    tmp31 = 1 + tmp16;
    tmp32 = runtime.safeCall(globalThis.Math.pow(tmp31, inlinedVal10));
    tmp33 = tmp32 - 1;
    tmp34 = c2 * tmp33;
    inlinedVal11 = tmp34 / tmp16;
  }
  inlinedVal3 = tmp15 + inlinedVal11;
  p3 = CompoundInterest2.principal;
  c3 = CompoundInterest2.monthlyContribution;
  r2 = CompoundInterest2.annualRate;
  tmp7 = r2 / CompoundInterest2.monthsPerYear;
  tmp8 = 1 + tmp7;
  inlinedVal12 = CompoundInterest2.monthsPerYear * t;
  tmp9 = runtime.safeCall(globalThis.Math.pow(tmp8, inlinedVal12));
  tmp10 = p3 * tmp9;
  tmp11 = r2 / CompoundInterest2.monthsPerYear;
  inlinedVal13 = CompoundInterest2.monthsPerYear * t;
  scrut = tmp11 == 0;
  if (scrut === true) {
    inlinedVal14 = c3 * inlinedVal13;
  } else {
    tmp27 = 1 + tmp11;
    tmp28 = runtime.safeCall(globalThis.Math.pow(tmp27, inlinedVal13));
    tmp29 = tmp28 - 1;
    tmp30 = c3 * tmp29;
    inlinedVal14 = tmp30 / tmp11;
  }
  inlinedVal4 = tmp10 + inlinedVal14;
  p4 = CompoundInterest2.principal;
  c4 = CompoundInterest2.monthlyContribution;
  r3 = CompoundInterest2.annualRate;
  tmp2 = r3 * t;
  tmp3 = 1 + tmp2;
  tmp4 = p4 * tmp3;
  inlinedVal15 = CompoundInterest2.monthsPerYear * t;
  tmp5 = c4 * inlinedVal15;
  tmp6 = tmp4 + tmp5;
  inlinedVal16 = CompoundInterest2.monthsPerYear * t;
  tmp22 = r3 / CompoundInterest2.monthsPerYear;
  tmp23 = c4 * tmp22;
  tmp24 = tmp23 * inlinedVal16;
  tmp25 = inlinedVal16 - 1;
  tmp26 = tmp24 * tmp25;
  inlinedVal17 = tmp26 / 2;
  inlinedVal5 = tmp6 + inlinedVal17;
  tmp = inlinedVal4 - inlinedVal5;
  return globalThis.Object.freeze([
    t,
    inlinedVal,
    inlinedVal2,
    inlinedVal3,
    tmp
  ])
});
(class CompoundInterest {
  static {
    CompoundInterest1 = this
  }
  static {
    let tmp, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, lambda$here, inlinedVal, sourceTable, rows, inlinedVal1, sourceTable1, inlinedVal2, inlinedVal3, inlinedVal4, inlinedVal5, inlinedVal6, inlinedVal7, inlinedVal8, root, order, inlinedVal9, root1, order1, inlinedVal10;
    CompoundInterest.principal = 10000;
    CompoundInterest.annualRate = 0.03;
    CompoundInterest.years = 10;
    CompoundInterest.monthlyContribution = 100;
    CompoundInterest.monthsPerYear = 12;
    tmp = globalThis.Object.freeze([
      "Parameter",
      "Value",
      "Units / convention"
    ]);
    tmp1 = globalThis.Object.freeze([
      "principal",
      CompoundInterest.principal,
      "USD paid at time zero"
    ]);
    tmp2 = globalThis.Object.freeze([
      "annualRate",
      CompoundInterest.annualRate,
      "Nominal annual fraction; 0.03 = 3%; try 0.06"
    ]);
    tmp3 = globalThis.Object.freeze([
      "years",
      CompoundInterest.years,
      "Nonnegative integer years; try 30"
    ]);
    tmp4 = globalThis.Object.freeze([
      "monthlyContribution",
      CompoundInterest.monthlyContribution,
      "USD deposited at every month end; try 0 first"
    ]);
    tmp5 = globalThis.Object.freeze([
      "monthsPerYear",
      CompoundInterest.monthsPerYear,
      "Fixed monthly/calendar convention; keep at 12"
    ]);
    tmp6 = globalThis.Object.freeze([
      "Contribution timing",
      "End of month",
      "Final month's deposit has no time to earn interest"
    ]);
    tmp7 = globalThis.Object.freeze([
      "Excluded effects",
      "Taxes, fees, inflation, withdrawals",
      "Constant rate and contribution; not a forecast"
    ]);
    tmp8 = globalThis.Object.freeze([
      tmp1,
      tmp2,
      tmp3,
      tmp4,
      tmp5,
      tmp6,
      tmp7
    ]);
    inlinedVal = globalThis.Object.freeze([
      "table",
      "ci-assumptions",
      "Editable assumptions (green cells patch this module)",
      tmp,
      tmp8
    ]);
    CompoundInterest.assumptions = inlinedVal;
    tmp9 = CompoundInterest.annualPoints(CompoundInterest.years);
    lambda$here = lambda$(CompoundInterest);
    tmp10 = runtime.safeCall(tmp9.map(lambda$here));
    CompoundInterest.annualRows = tmp10;
    tmp11 = globalThis.Object.freeze([
      "Year",
      "Cash paid in (USD)",
      "Simple balance (USD)",
      "Compound balance (USD)",
      "Compound minus simple (USD)"
    ]);
    sourceTable = CompoundInterest.assumptions;
    rows = CompoundInterest.annualRows;
    inlinedVal1 = globalThis.Object.freeze([
      "derived",
      "ci-annual-results",
      "Annual results: identical cash flows, different interest rules",
      tmp11,
      rows,
      sourceTable
    ]);
    CompoundInterest.annualResults = inlinedVal1;
    tmp12 = globalThis.Object.freeze([
      "Simple balance (USD)",
      "Compound balance (USD)"
    ]);
    sourceTable1 = CompoundInterest.annualResults;
    inlinedVal2 = globalThis.Object.freeze([
      "line",
      "ci-comparison",
      "Annual balances (USD): simple vs monthly compound",
      sourceTable1,
      "Year",
      tmp12
    ]);
    CompoundInterest.comparison = inlinedVal2;
    inlinedVal3 = globalThis.Object.freeze([
      "text",
      "ci-introduction",
      "Finance student: understanding compound interest",
      "Synthetic illustrative educational inputs, not live market or experimental data. Compare simple interest with monthly compounding at annual time points. Both methods receive the same initial principal and end-of-month contributions. Edit a green assumption cell in the document view or edit the named literal in the source pane. The combined workspace patches the owning literal, recompiles with hkmc2 and refreshes the view; computed annual results and line points are read-only with source links."
    ]);
    CompoundInterest.introduction = inlinedVal3;
    inlinedVal4 = globalThis.Object.freeze([
      "text",
      "ci-formulas",
      "Fair treatment of contributions",
      "Let P be initial USD, C be USD deposited at each month end, r the nominal annual rate, t elapsed years, m = 12*t, and i = r/12. Simple balance = P*(1+r*t) + C*m + C*i*m*(m-1)/2. A deposit made at month k earns only C*i*(m-k) simple interest; none of its interest earns interest. Compound balance = P*(1+i)^m + C*((1+i)^m-1)/i. When i = 0, the contribution term is C*m and both balances equal P+C*m. The rate is nominal annual, not an effective annual yield."
    ]);
    CompoundInterest.formulas = inlinedVal4;
    inlinedVal5 = globalThis.Object.freeze([
      "text",
      "ci-interpretation",
      "Interpretation and suggested experiment",
      "First set monthlyContribution = 0: the simple balance is linear in time, while positive-rate monthly compounding curves upward. Restore contributions: even the simple balance can bend because each new deposit adds another source of future simple interest. This is not compounding of interest. Change annualRate from 0.03 to 0.06, and years from 10 to 30, rebuilding after each edit; inspect the computed gap in the annual table and the two lines in the single overlay plot. Try annualRate = 0 to verify that both balances match cash paid in. Longer time and higher positive rates generally widen the compounding advantage for these nonnegative cash flows. Annual plotted points sample monthly accumulation; the connecting lines are not intra-year observations. Green assumption cells are editable; computed annual results and line points are read-only and reveal their source literals."
    ]);
    CompoundInterest.interpretation = inlinedVal5;
    tmp13 = globalThis.Object.freeze([
      CompoundInterest.assumptions,
      CompoundInterest.formulas
    ]);
    inlinedVal6 = globalThis.Object.freeze([
      "group",
      "ci-inputs-group",
      "Inputs and mathematical conventions",
      tmp13
    ]);
    CompoundInterest.inputsGroup = inlinedVal6;
    tmp14 = globalThis.Object.freeze([
      CompoundInterest.annualResults,
      CompoundInterest.comparison,
      CompoundInterest.interpretation
    ]);
    inlinedVal7 = globalThis.Object.freeze([
      "group",
      "ci-results-group",
      "Computed comparison with provenance",
      tmp14
    ]);
    CompoundInterest.resultsGroup = inlinedVal7;
    tmp15 = globalThis.Object.freeze([
      CompoundInterest.introduction,
      CompoundInterest.inputsGroup,
      CompoundInterest.resultsGroup
    ]);
    inlinedVal8 = globalThis.Object.freeze([
      "group",
      "ci-report",
      "Simple interest versus monthly compounding",
      tmp15
    ]);
    CompoundInterest.report = inlinedVal8;
    tmp16 = globalThis.Object.freeze([
      "ci-introduction",
      "ci-assumptions",
      "ci-formulas",
      "ci-annual-results",
      "ci-comparison",
      "ci-interpretation"
    ]);
    CompoundInterest.displayOrder = tmp16;
    root = CompoundInterest.report;
    order = CompoundInterest.displayOrder;
    inlinedVal9 = runtime.safeCall(Render.render(root, order));
    CompoundInterest.document = inlinedVal9;
    root1 = CompoundInterest.report;
    order1 = CompoundInterest.displayOrder;
    inlinedVal10 = runtime.safeCall(Render.model(root1, order1));
    CompoundInterest.model = inlinedVal10;
  }
  static annualPoints(n) {
    let scrut, tmp, tmp1;
    scrut = n <= 0;
    if (scrut === true) {
      return globalThis.Object.freeze([
        0
      ])
    }
    tmp = n - 1;
    tmp1 = CompoundInterest.annualPoints(tmp);
    return globalThis.Object.freeze([
      ...tmp1,
      n
    ]);
  }
  static monthsAt(t) {
    return CompoundInterest.monthsPerYear * t
  }
  static cashPaidIn(p, c, t) {
    let tmp, tmp1;
    tmp = CompoundInterest.monthsAt(t);
    tmp1 = c * tmp;
    return p + tmp1
  }
  static simpleContributionInterest(c, r, m) {
    let tmp, tmp1, tmp2, tmp3, tmp4;
    tmp = r / CompoundInterest.monthsPerYear;
    tmp1 = c * tmp;
    tmp2 = tmp1 * m;
    tmp3 = m - 1;
    tmp4 = tmp2 * tmp3;
    return tmp4 / 2
  }
  static simpleFutureValue(p, c, r, t) {
    let tmp, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7;
    tmp = r * t;
    tmp1 = 1 + tmp;
    tmp2 = p * tmp1;
    tmp3 = CompoundInterest.monthsAt(t);
    tmp4 = c * tmp3;
    tmp5 = tmp2 + tmp4;
    tmp6 = CompoundInterest.monthsAt(t);
    tmp7 = CompoundInterest.simpleContributionInterest(c, r, tmp6);
    return tmp5 + tmp7
  }
  static contributionFutureValue(c, monthlyRate, m) {
    let scrut, tmp, tmp1, tmp2, tmp3;
    scrut = monthlyRate == 0;
    if (scrut === true) {
      return c * m
    }
    tmp = 1 + monthlyRate;
    tmp1 = runtime.safeCall(globalThis.Math.pow(tmp, m));
    tmp2 = tmp1 - 1;
    tmp3 = c * tmp2;
    return tmp3 / monthlyRate;
  }
  static compoundFutureValue(p, c, r, t) {
    let tmp, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7;
    tmp = r / CompoundInterest.monthsPerYear;
    tmp1 = 1 + tmp;
    tmp2 = CompoundInterest.monthsAt(t);
    tmp3 = runtime.safeCall(globalThis.Math.pow(tmp1, tmp2));
    tmp4 = p * tmp3;
    tmp5 = r / CompoundInterest.monthsPerYear;
    tmp6 = CompoundInterest.monthsAt(t);
    tmp7 = CompoundInterest.contributionFutureValue(c, tmp5, tmp6);
    return tmp4 + tmp7
  }
  static simpleAt(t) {
    return CompoundInterest.simpleFutureValue(CompoundInterest.principal, CompoundInterest.monthlyContribution, CompoundInterest.annualRate, t)
  }
  static compoundAt(t) {
    return CompoundInterest.compoundFutureValue(CompoundInterest.principal, CompoundInterest.monthlyContribution, CompoundInterest.annualRate, t)
  }
  toString() { return runtime.render(this); }
  static [definitionMetadata] = ["class", "CompoundInterest"];
});
export { CompoundInterest1 as _$_modulePrivate_$_CompoundInterest };
export { lambda as _$_modulePrivate_$_lambda };
export { lambda$ as _$_modulePrivate_$_lambda$ };
let CompoundInterest = CompoundInterest1; export default CompoundInterest;
