const definitionMetadata = globalThis.Symbol.for("mlscript.definitionMetadata");
const prettyPrint = globalThis.Symbol.for("mlscript.prettyPrint");
import runtime from "file:///c:/Users/ytoh9/.vscode/extensions/mlscript-studio.mlscript-studio-0.7.1/runtime/std/Runtime.mjs";
import Studio from "file:///c:/Users/ytoh9/OneDrive/%EB%B0%94%ED%83%95%20%ED%99%94%EB%A9%B4/mlscropt%200.7.1/library/Studio.mjs";
import Render from "file:///c:/Users/ytoh9/OneDrive/%EB%B0%94%ED%83%95%20%ED%99%94%EB%A9%B4/mlscropt%200.7.1/library/Render.mjs";
let CoolingExperiment1, lambda, lambda1, lambda2, lambda3, lambda4, lambda$, lambda$1, lambda$2, lambda$3, lambda$4;
lambda$4 = (undefined, function (CoolingExperiment2) {
  return (total, row) => {
    return lambda3(CoolingExperiment2, total, row)
  }
});
lambda3 = (undefined, function (CoolingExperiment2, total, row) {
  let inlinedVal, timeMinutes, inlinedVal1, tmp, tmp1, tmp2, tmp3, tmp4;
  timeMinutes = row[0];
  tmp = CoolingExperiment2.initialTemperatureC - CoolingExperiment2.ambientTemperatureC;
  tmp1 = CoolingExperiment2.coolingCoefficientPerMinute * timeMinutes;
  tmp2 = - tmp1;
  tmp3 = runtime.safeCall(globalThis.Math.exp(tmp2));
  tmp4 = tmp * tmp3;
  inlinedVal1 = CoolingExperiment2.ambientTemperatureC + tmp4;
  inlinedVal = row[1] - inlinedVal1;
  return total + inlinedVal
});
lambda$3 = (undefined, function (CoolingExperiment2) {
  return (total, row) => {
    return lambda2(CoolingExperiment2, total, row)
  }
});
lambda2 = (undefined, function (CoolingExperiment2, total, row) {
  let tmp, inlinedVal, timeMinutes, inlinedVal1, tmp1, tmp2, tmp3, tmp4, tmp5;
  timeMinutes = row[0];
  tmp1 = CoolingExperiment2.initialTemperatureC - CoolingExperiment2.ambientTemperatureC;
  tmp2 = CoolingExperiment2.coolingCoefficientPerMinute * timeMinutes;
  tmp3 = - tmp2;
  tmp4 = runtime.safeCall(globalThis.Math.exp(tmp3));
  tmp5 = tmp1 * tmp4;
  inlinedVal1 = CoolingExperiment2.ambientTemperatureC + tmp5;
  inlinedVal = row[1] - inlinedVal1;
  tmp = runtime.safeCall(globalThis.Math.abs(inlinedVal));
  return total + tmp
});
lambda$2 = (undefined, function (CoolingExperiment2) {
  return (total, row) => {
    return lambda1(CoolingExperiment2, total, row)
  }
});
lambda1 = (undefined, function (CoolingExperiment2, total, row) {
  let tmp, inlinedVal, inlinedVal1, timeMinutes, inlinedVal2, timeMinutes1, inlinedVal3, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10;
  timeMinutes = row[0];
  tmp6 = CoolingExperiment2.initialTemperatureC - CoolingExperiment2.ambientTemperatureC;
  tmp7 = CoolingExperiment2.coolingCoefficientPerMinute * timeMinutes;
  tmp8 = - tmp7;
  tmp9 = runtime.safeCall(globalThis.Math.exp(tmp8));
  tmp10 = tmp6 * tmp9;
  inlinedVal2 = CoolingExperiment2.ambientTemperatureC + tmp10;
  inlinedVal = row[1] - inlinedVal2;
  timeMinutes1 = row[0];
  tmp1 = CoolingExperiment2.initialTemperatureC - CoolingExperiment2.ambientTemperatureC;
  tmp2 = CoolingExperiment2.coolingCoefficientPerMinute * timeMinutes1;
  tmp3 = - tmp2;
  tmp4 = runtime.safeCall(globalThis.Math.exp(tmp3));
  tmp5 = tmp1 * tmp4;
  inlinedVal3 = CoolingExperiment2.ambientTemperatureC + tmp5;
  inlinedVal1 = row[1] - inlinedVal3;
  tmp = inlinedVal * inlinedVal1;
  return total + tmp
});
lambda$1 = (undefined, function (excludeFlagged) {
  return (row) => {
    return lambda(excludeFlagged, row)
  }
});
lambda = (undefined, function (excludeFlagged, row) {
  if (excludeFlagged === true) {
    return row[2] == false
  }
  return true;
});
lambda$ = (undefined, function (CoolingExperiment2) {
  return (row) => {
    return lambda4(CoolingExperiment2, row)
  }
});
lambda4 = (undefined, function (CoolingExperiment2, row) {
  let tmp, timeMinutes, inlinedVal, inlinedVal1, inlinedVal2, tmp1, tmp2, tmp3, tmp4, tmp5, timeMinutes1, inlinedVal3, timeMinutes2, inlinedVal4, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15;
  timeMinutes = row[0];
  tmp1 = CoolingExperiment2.initialTemperatureC - CoolingExperiment2.ambientTemperatureC;
  tmp2 = CoolingExperiment2.coolingCoefficientPerMinute * timeMinutes;
  tmp3 = - tmp2;
  tmp4 = runtime.safeCall(globalThis.Math.exp(tmp3));
  tmp5 = tmp1 * tmp4;
  inlinedVal = CoolingExperiment2.ambientTemperatureC + tmp5;
  timeMinutes1 = row[0];
  tmp11 = CoolingExperiment2.initialTemperatureC - CoolingExperiment2.ambientTemperatureC;
  tmp12 = CoolingExperiment2.coolingCoefficientPerMinute * timeMinutes1;
  tmp13 = - tmp12;
  tmp14 = runtime.safeCall(globalThis.Math.exp(tmp13));
  tmp15 = tmp11 * tmp14;
  inlinedVal3 = CoolingExperiment2.ambientTemperatureC + tmp15;
  inlinedVal1 = row[1] - inlinedVal3;
  timeMinutes2 = row[0];
  tmp6 = CoolingExperiment2.initialTemperatureC - CoolingExperiment2.ambientTemperatureC;
  tmp7 = CoolingExperiment2.coolingCoefficientPerMinute * timeMinutes2;
  tmp8 = - tmp7;
  tmp9 = runtime.safeCall(globalThis.Math.exp(tmp8));
  tmp10 = tmp6 * tmp9;
  inlinedVal4 = CoolingExperiment2.ambientTemperatureC + tmp10;
  inlinedVal2 = row[1] - inlinedVal4;
  tmp = runtime.safeCall(globalThis.Math.abs(inlinedVal2));
  return globalThis.Object.freeze([
    row[0],
    row[1],
    inlinedVal,
    inlinedVal1,
    tmp,
    row[2]
  ])
});
(class CoolingExperiment {
  static {
    CoolingExperiment1 = this
  }
  static {
    let scrut, tmp, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29, tmp30, tmp31, tmp32, tmp33, tmp34, tmp35, tmp36, tmp37, tmp38, tmp39, tmp40, tmp41, tmp42, tmp43, tmp44, tmp45, tmp46, tmp47, tmp48, tmp49, tmp50, tmp51, lambda$here, inlinedVal, inlinedVal1, inlinedVal2, rows, inlinedVal3, sourceTable, inlinedVal4, sourceTable1, rows1, inlinedVal5, sourceTable2, inlinedVal6, sourceTable3, inlinedVal7, inlinedVal8, inlinedVal9, inlinedVal10, inlinedVal11, root, order, inlinedVal12, root1, order1, inlinedVal13;
    CoolingExperiment.ambientTemperatureC = 22;
    CoolingExperiment.initialTemperatureC = 85;
    CoolingExperiment.coolingCoefficientPerMinute = 0.10;
    CoolingExperiment.excludeSensorErrors = true;
    tmp = globalThis.Object.freeze([
      0,
      80.2,
      false,
      "Start reading; synthetic prepared input"
    ]);
    tmp1 = globalThis.Object.freeze([
      2,
      73.3,
      false,
      "No documented sensor error"
    ]);
    tmp2 = globalThis.Object.freeze([
      4,
      64.5,
      false,
      "No documented sensor error"
    ]);
    tmp3 = globalThis.Object.freeze([
      6,
      56.8,
      false,
      "No documented sensor error"
    ]);
    tmp4 = globalThis.Object.freeze([
      8,
      50.5,
      false,
      "No documented sensor error"
    ]);
    tmp5 = globalThis.Object.freeze([
      10,
      90.0,
      true,
      "Synthetic sensor log: transient probe disconnection"
    ]);
    tmp6 = globalThis.Object.freeze([
      12,
      42.1,
      false,
      "No documented sensor error"
    ]);
    tmp7 = globalThis.Object.freeze([
      14,
      38.6,
      false,
      "No documented sensor error"
    ]);
    tmp8 = globalThis.Object.freeze([
      16,
      35.7,
      false,
      "No documented sensor error"
    ]);
    tmp9 = globalThis.Object.freeze([
      18,
      33.5,
      false,
      "No documented sensor error"
    ]);
    tmp10 = globalThis.Object.freeze([
      20,
      31.6,
      false,
      "No documented sensor error"
    ]);
    tmp11 = globalThis.Object.freeze([
      tmp,
      tmp1,
      tmp2,
      tmp3,
      tmp4,
      tmp5,
      tmp6,
      tmp7,
      tmp8,
      tmp9,
      tmp10
    ]);
    CoolingExperiment.measurements = tmp11;
    tmp12 = CoolingExperiment.retainedRows(CoolingExperiment.excludeSensorErrors);
    CoolingExperiment.selectedRows = tmp12;
    tmp13 = CoolingExperiment.retainedRows(true);
    CoolingExperiment.unflaggedRows = tmp13;
    lambda$here = lambda$(CoolingExperiment);
    tmp14 = runtime.safeCall(CoolingExperiment.selectedRows.map(lambda$here));
    CoolingExperiment.comparisonRows = tmp14;
    scrut = CoolingExperiment.excludeSensorErrors;
    if (scrut === true) {
      tmp15 = "Exclude only documented sensor errors";
    } else {
      tmp15 = "Retain every prepared reading";
    }
    CoolingExperiment.policyLabel = tmp15;
    inlinedVal = globalThis.Object.freeze([
      "text",
      "cooling-purpose",
      "Engineering student: cooling measurements vs theory",
      "Synthetic educational reproduction of case02.pdf. Compare a prepared measurement dataset against Newton cooling, then change model assumptions, a raw observed temperature, or the documented-error exclusion rule. Green assumption and raw-reading cells are editable; the raw temperature chart is draggable. These are illustrative demo inputs, not live or experimental data; no CSV has been imported."
    ]);
    CoolingExperiment.purpose = inlinedVal;
    tmp16 = globalThis.Object.freeze([
      "Parameter",
      "Value",
      "Unit or rule"
    ]);
    tmp17 = globalThis.Object.freeze([
      "ambientTemperatureC",
      CoolingExperiment.ambientTemperatureC,
      "degrees C; constant ambient"
    ]);
    tmp18 = globalThis.Object.freeze([
      "initialTemperatureC",
      CoolingExperiment.initialTemperatureC,
      "degrees C at time zero; specified, not fitted"
    ]);
    tmp19 = globalThis.Object.freeze([
      "coolingCoefficientPerMinute",
      CoolingExperiment.coolingCoefficientPerMinute,
      "1/min; use a positive value"
    ]);
    tmp20 = globalThis.Object.freeze([
      "excludeSensorErrors",
      CoolingExperiment.excludeSensorErrors,
      "Exclude only rows with sensor_error = true"
    ]);
    tmp21 = globalThis.Object.freeze([
      "Prepared readings",
      CoolingExperiment.measurements.length,
      "rows"
    ]);
    tmp22 = globalThis.Object.freeze([
      "Retained readings",
      CoolingExperiment.selectedRows.length,
      "rows"
    ]);
    tmp23 = CoolingExperiment.measurements.length - CoolingExperiment.selectedRows.length;
    tmp24 = globalThis.Object.freeze([
      "Excluded readings",
      tmp23,
      "rows"
    ]);
    tmp25 = globalThis.Object.freeze([
      tmp17,
      tmp18,
      tmp19,
      tmp20,
      tmp21,
      tmp22,
      tmp24
    ]);
    inlinedVal1 = globalThis.Object.freeze([
      "table",
      "cooling-assumptions",
      "Editable model and processing assumptions",
      tmp16,
      tmp25
    ]);
    CoolingExperiment.assumptions = inlinedVal1;
    tmp26 = "Rule: " + CoolingExperiment.policyLabel;
    tmp27 = tmp26 + ". Filtering never changes the raw table and never removes readings merely for large residuals. The model is evaluated at each retained measurement time; no interpolation, smoothing, parameter fitting, or sensor correction is applied. Residual = observed minus predicted, in degrees C; a positive residual means the observation is hotter than the model. The overlay connects retained sample points, so a line across a missing reading is not an imputed measurement. Edit a green raw cell or drag the raw-temperature bar to patch the measurement literal; computed comparison and metric tables are read-only with source links.";
    inlinedVal2 = globalThis.Object.freeze([
      "text",
      "cooling-processing",
      "Visible processing and interpretation",
      tmp27
    ]);
    CoolingExperiment.processing = inlinedVal2;
    tmp28 = globalThis.Object.freeze([
      "time_min",
      "observed_C",
      "sensor_error",
      "documentation"
    ]);
    rows = CoolingExperiment.measurements;
    inlinedVal3 = globalThis.Object.freeze([
      "table",
      "cooling-raw",
      "Prepared measurements \u2014 SYNTHETIC demo inputs (green cells are editable)",
      tmp28,
      rows
    ]);
    CoolingExperiment.rawTable = inlinedVal3;
    sourceTable = CoolingExperiment.rawTable;
    inlinedVal4 = globalThis.Object.freeze([
      "bar",
      "cooling-raw-chart",
      "Raw observed temperatures (drag a green bar to edit the reading)",
      sourceTable,
      "time_min",
      "observed_C"
    ]);
    CoolingExperiment.rawTemperatureChart = inlinedVal4;
    tmp29 = globalThis.Object.freeze([
      "time_min",
      "Observed_C",
      "Predicted_C",
      "Residual_C",
      "Absolute_error_C",
      "sensor_error"
    ]);
    sourceTable1 = CoolingExperiment.rawTable;
    rows1 = CoolingExperiment.comparisonRows;
    inlinedVal5 = globalThis.Object.freeze([
      "derived",
      "cooling-comparison",
      "Retained observations and Newton predictions",
      tmp29,
      rows1,
      sourceTable1
    ]);
    CoolingExperiment.comparisonTable = inlinedVal5;
    tmp30 = globalThis.Object.freeze([
      "Observed_C",
      "Predicted_C"
    ]);
    sourceTable2 = CoolingExperiment.comparisonTable;
    inlinedVal6 = globalThis.Object.freeze([
      "line",
      "cooling-overlay",
      "Measured vs predicted temperature (minutes; degrees C)",
      sourceTable2,
      "time_min",
      tmp30
    ]);
    CoolingExperiment.overlay = inlinedVal6;
    tmp31 = globalThis.Object.freeze([
      "Policy",
      "Retained_n",
      "Excluded_n",
      "RMSE_C",
      "MAE_C",
      "Mean_residual_C"
    ]);
    tmp32 = "Current: " + CoolingExperiment.policyLabel;
    tmp33 = CoolingExperiment.measurements.length - CoolingExperiment.selectedRows.length;
    tmp34 = CoolingExperiment.rmseC(CoolingExperiment.selectedRows);
    tmp35 = CoolingExperiment.maeC(CoolingExperiment.selectedRows);
    tmp36 = CoolingExperiment.meanResidualC(CoolingExperiment.selectedRows);
    tmp37 = globalThis.Object.freeze([
      tmp32,
      CoolingExperiment.selectedRows.length,
      tmp33,
      tmp34,
      tmp35,
      tmp36
    ]);
    tmp38 = CoolingExperiment.rmseC(CoolingExperiment.measurements);
    tmp39 = CoolingExperiment.maeC(CoolingExperiment.measurements);
    tmp40 = CoolingExperiment.meanResidualC(CoolingExperiment.measurements);
    tmp41 = globalThis.Object.freeze([
      "All prepared readings",
      CoolingExperiment.measurements.length,
      0,
      tmp38,
      tmp39,
      tmp40
    ]);
    tmp42 = CoolingExperiment.measurements.length - CoolingExperiment.unflaggedRows.length;
    tmp43 = CoolingExperiment.rmseC(CoolingExperiment.unflaggedRows);
    tmp44 = CoolingExperiment.maeC(CoolingExperiment.unflaggedRows);
    tmp45 = CoolingExperiment.meanResidualC(CoolingExperiment.unflaggedRows);
    tmp46 = globalThis.Object.freeze([
      "Exclude documented sensor errors",
      CoolingExperiment.unflaggedRows.length,
      tmp42,
      tmp43,
      tmp44,
      tmp45
    ]);
    tmp47 = globalThis.Object.freeze([
      tmp37,
      tmp41,
      tmp46
    ]);
    sourceTable3 = CoolingExperiment.rawTable;
    inlinedVal7 = globalThis.Object.freeze([
      "derived",
      "cooling-errors",
      "Computed residual metrics and processing sensitivity",
      tmp31,
      tmp47,
      sourceTable3
    ]);
    CoolingExperiment.errorMetrics = inlinedVal7;
    inlinedVal8 = globalThis.Object.freeze([
      "text",
      "cooling-metric-notes",
      "How to explain discrepancies",
      "RMSE = sqrt(mean(residual squared)); MAE = mean(abs(residual)); mean residual shows signed bias. All three use degrees C and describe only the retained sample times. Changing ambient temperature or k recomputes predictions and metrics; changing the exclusion flag changes which observations contribute. A lower error after removing the documented fault is not evidence that Newton cooling is universally valid. Real experiments could also differ because ambient temperature varies, heat loss is not lumped, or sensors are noisy; those mechanisms are not identified by this synthetic example."
    ]);
    CoolingExperiment.metricNotes = inlinedVal8;
    tmp48 = globalThis.Object.freeze([
      CoolingExperiment.purpose,
      CoolingExperiment.assumptions,
      CoolingExperiment.processing
    ]);
    inlinedVal9 = globalThis.Object.freeze([
      "group",
      "cooling-context",
      "Model assumptions and reproducibility",
      tmp48
    ]);
    CoolingExperiment.contextGroup = inlinedVal9;
    tmp49 = globalThis.Object.freeze([
      CoolingExperiment.rawTable,
      CoolingExperiment.rawTemperatureChart,
      CoolingExperiment.comparisonTable,
      CoolingExperiment.overlay,
      CoolingExperiment.errorMetrics,
      CoolingExperiment.metricNotes
    ]);
    inlinedVal10 = globalThis.Object.freeze([
      "group",
      "cooling-evidence",
      "Raw-to-derived comparison with provenance",
      tmp49
    ]);
    CoolingExperiment.evidenceGroup = inlinedVal10;
    tmp50 = globalThis.Object.freeze([
      CoolingExperiment.contextGroup,
      CoolingExperiment.evidenceGroup
    ]);
    inlinedVal11 = globalThis.Object.freeze([
      "group",
      "cooling-report",
      "Cooling experiment \u2014 synthetic educational analysis",
      tmp50
    ]);
    CoolingExperiment.report = inlinedVal11;
    tmp51 = globalThis.Object.freeze([
      "cooling-purpose",
      "cooling-assumptions",
      "cooling-processing",
      "cooling-raw",
      "cooling-raw-chart",
      "cooling-overlay",
      "cooling-comparison",
      "cooling-errors",
      "cooling-metric-notes"
    ]);
    CoolingExperiment.displayOrder = tmp51;
    root = CoolingExperiment.report;
    order = CoolingExperiment.displayOrder;
    inlinedVal12 = runtime.safeCall(Render.render(root, order));
    CoolingExperiment.document = inlinedVal12;
    root1 = CoolingExperiment.report;
    order1 = CoolingExperiment.displayOrder;
    inlinedVal13 = runtime.safeCall(Render.model(root1, order1));
    CoolingExperiment.model = inlinedVal13;
  }
  static predictedTemperatureC(timeMinutes) {
    let tmp, tmp1, tmp2, tmp3, tmp4;
    tmp = CoolingExperiment.initialTemperatureC - CoolingExperiment.ambientTemperatureC;
    tmp1 = CoolingExperiment.coolingCoefficientPerMinute * timeMinutes;
    tmp2 = - tmp1;
    tmp3 = runtime.safeCall(globalThis.Math.exp(tmp2));
    tmp4 = tmp * tmp3;
    return CoolingExperiment.ambientTemperatureC + tmp4
  }
  static residualC(row) {
    let tmp;
    tmp = CoolingExperiment.predictedTemperatureC(row[0]);
    return row[1] - tmp
  }
  static retainedRows(excludeFlagged) {
    let lambda$here;
    lambda$here = lambda$1(excludeFlagged);
    return runtime.safeCall(CoolingExperiment.measurements.filter(lambda$here))
  }
  static squaredErrorTotal(rows) {
    let lambda$here;
    lambda$here = lambda$2(CoolingExperiment);
    return runtime.safeCall(rows.reduce(lambda$here, 0))
  }
  static absoluteErrorTotal(rows) {
    let lambda$here;
    lambda$here = lambda$3(CoolingExperiment);
    return runtime.safeCall(rows.reduce(lambda$here, 0))
  }
  static rmseC(rows) {
    let tmp, tmp1;
    tmp = CoolingExperiment.squaredErrorTotal(rows);
    tmp1 = tmp / rows.length;
    return runtime.safeCall(globalThis.Math.sqrt(tmp1))
  }
  static maeC(rows) {
    let tmp;
    tmp = CoolingExperiment.absoluteErrorTotal(rows);
    return tmp / rows.length
  }
  static meanResidualC(rows) {
    let tmp, lambda$here;
    lambda$here = lambda$4(CoolingExperiment);
    tmp = runtime.safeCall(rows.reduce(lambda$here, 0));
    return tmp / rows.length
  }
  toString() { return runtime.render(this); }
  static [definitionMetadata] = ["class", "CoolingExperiment"];
});
export { CoolingExperiment1 as _$_modulePrivate_$_CoolingExperiment };
export { lambda as _$_modulePrivate_$_lambda };
export { lambda1 as _$_modulePrivate_$_lambda1 };
export { lambda2 as _$_modulePrivate_$_lambda2 };
export { lambda3 as _$_modulePrivate_$_lambda3 };
export { lambda4 as _$_modulePrivate_$_lambda4 };
export { lambda$ as _$_modulePrivate_$_lambda$ };
export { lambda$1 as _$_modulePrivate_$_lambda$1 };
export { lambda$2 as _$_modulePrivate_$_lambda$2 };
export { lambda$3 as _$_modulePrivate_$_lambda$3 };
export { lambda$4 as _$_modulePrivate_$_lambda$4 };
let CoolingExperiment = CoolingExperiment1; export default CoolingExperiment;
