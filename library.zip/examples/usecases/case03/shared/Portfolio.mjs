const definitionMetadata = globalThis.Symbol.for("mlscript.definitionMetadata");
const prettyPrint = globalThis.Symbol.for("mlscript.prettyPrint");
import runtime from "file:///c:/Users/ytoh9/.vscode/extensions/mlscript-studio.mlscript-studio-0.7.1/runtime/std/Runtime.mjs";
import Studio from "file:///c:/Users/ytoh9/OneDrive/%EB%B0%94%ED%83%95%20%ED%99%94%EB%A9%B4/mlscropt%200.7.1/library/Studio.mjs";
let Portfolio1, lambda, lambda1, lambda2, lambda3, lambda4, lambda5, lambda6, lambda7, lambda8, lambda$, lambda$1, lambda$2, lambda$3, lambda$4, lambda$5;
lambda1 = (undefined, function (worst, state) {
  let scrut;
  scrut = state[4] < worst;
  if (scrut === true) {
    return state[4]
  }
  return worst;
});
lambda$5 = (undefined, function (Portfolio2, allocation) {
  return (path, row) => {
    return lambda(Portfolio2, allocation, path, row)
  }
});
lambda = (undefined, function (Portfolio2, allocation, path, row) {
  let tmp, inlinedVal, inlinedVal1, inlinedVal2, month, inlinedVal3, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, scrut, tmp7, tmp8, tmp9, tmp10, inlinedVal4, inlinedVal5, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16;
  tmp = runtime.safeCall(path.at(-1));
  tmp14 = row[1] * allocation[1];
  tmp15 = row[2] * allocation[2];
  tmp16 = tmp14 + tmp15;
  inlinedVal4 = tmp16 - Portfolio2.monthlyCostPercent;
  tmp9 = inlinedVal4 / 100;
  tmp10 = 1 + tmp9;
  inlinedVal = tmp[1] * tmp10;
  tmp11 = row[1] * allocation[1];
  tmp12 = row[2] * allocation[2];
  tmp13 = tmp11 + tmp12;
  inlinedVal5 = tmp13 - Portfolio2.monthlyCostPercent;
  tmp7 = inlinedVal5 / 100;
  tmp8 = 1 + tmp7;
  inlinedVal1 = tmp[1] * tmp8;
  scrut = inlinedVal1 > tmp[2];
  if (scrut === true) {
    inlinedVal2 = inlinedVal1;
  } else {
    inlinedVal2 = tmp[2];
  }
  month = row[0];
  tmp1 = inlinedVal / Portfolio2.initialCapitalUsd;
  tmp2 = tmp1 - 1;
  tmp3 = 100 * tmp2;
  tmp4 = inlinedVal / inlinedVal2;
  tmp5 = tmp4 - 1;
  tmp6 = 100 * tmp5;
  inlinedVal3 = globalThis.Object.freeze([
    month,
    inlinedVal,
    inlinedVal2,
    tmp3,
    tmp6
  ]);
  return globalThis.Object.freeze([
    ...path,
    inlinedVal3
  ])
});
lambda$4 = (undefined, function (Portfolio2) {
  return (allocation) => {
    return lambda2(Portfolio2, allocation)
  }
});
lambda$3 = (undefined, function (Portfolio2) {
  return (row) => {
    return lambda5(Portfolio2, row)
  }
});
lambda$2 = (undefined, function (Portfolio2) {
  return (index) => {
    return lambda6(Portfolio2, index)
  }
});
lambda$1 = (undefined, function (Portfolio2) {
  return (index) => {
    return lambda7(Portfolio2, index)
  }
});
lambda$ = (undefined, function (Portfolio2) {
  return (index) => {
    return Portfolio2.endingRow(index)
  }
});
lambda2 = (undefined, function (Portfolio2, allocation) {
  let tmp, tmp1, lambda$here;
  tmp = globalThis.Object.freeze([
    0,
    Portfolio2.initialCapitalUsd,
    Portfolio2.initialCapitalUsd,
    0,
    0
  ]);
  tmp1 = globalThis.Object.freeze([
    tmp
  ]);
  lambda$here = lambda$5(Portfolio2, allocation);
  return runtime.safeCall(Portfolio2.monthlyAssetReturnsPercent.reduce(lambda$here, tmp1))
});
lambda3 = (undefined, function (row) {
  return row[0]
});
lambda4 = (undefined, function (allocation) {
  let tmp, tmp1;
  tmp = 100 * allocation[1];
  tmp1 = 100 * allocation[2];
  return globalThis.Object.freeze([
    allocation[0],
    tmp,
    tmp1
  ])
});
lambda5 = (undefined, function (Portfolio2, row) {
  let allocation, inlinedVal, inlinedVal1, allocation1, inlinedVal2, inlinedVal3, allocation2, inlinedVal4, inlinedVal5, tmp, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20;
  allocation = Portfolio2.allocations[0];
  tmp18 = row[1] * allocation[1];
  tmp19 = row[2] * allocation[2];
  tmp20 = tmp18 + tmp19;
  inlinedVal = tmp20 - Portfolio2.monthlyCostPercent;
  tmp14 = runtime.safeCall(globalThis.Math.pow(10, Portfolio2.displayDecimals));
  tmp15 = inlinedVal * tmp14;
  tmp16 = runtime.safeCall(globalThis.Math.round(tmp15));
  tmp17 = runtime.safeCall(globalThis.Math.pow(10, Portfolio2.displayDecimals));
  inlinedVal1 = tmp16 / tmp17;
  allocation1 = Portfolio2.allocations[1];
  tmp11 = row[1] * allocation1[1];
  tmp12 = row[2] * allocation1[2];
  tmp13 = tmp11 + tmp12;
  inlinedVal2 = tmp13 - Portfolio2.monthlyCostPercent;
  tmp7 = runtime.safeCall(globalThis.Math.pow(10, Portfolio2.displayDecimals));
  tmp8 = inlinedVal2 * tmp7;
  tmp9 = runtime.safeCall(globalThis.Math.round(tmp8));
  tmp10 = runtime.safeCall(globalThis.Math.pow(10, Portfolio2.displayDecimals));
  inlinedVal3 = tmp9 / tmp10;
  allocation2 = Portfolio2.allocations[2];
  tmp4 = row[1] * allocation2[1];
  tmp5 = row[2] * allocation2[2];
  tmp6 = tmp4 + tmp5;
  inlinedVal4 = tmp6 - Portfolio2.monthlyCostPercent;
  tmp = runtime.safeCall(globalThis.Math.pow(10, Portfolio2.displayDecimals));
  tmp1 = inlinedVal4 * tmp;
  tmp2 = runtime.safeCall(globalThis.Math.round(tmp1));
  tmp3 = runtime.safeCall(globalThis.Math.pow(10, Portfolio2.displayDecimals));
  inlinedVal5 = tmp2 / tmp3;
  return globalThis.Object.freeze([
    row[0],
    inlinedVal1,
    inlinedVal3,
    inlinedVal5
  ])
});
lambda6 = (undefined, function (Portfolio2, index) {
  let tmp, tmp1, tmp2, tmp3;
  tmp = runtime.safeCall(Portfolio2.monthNumbers.at(index));
  tmp1 = runtime.safeCall(Portfolio2.allocationPaths[0].at(index));
  tmp2 = runtime.safeCall(Portfolio2.allocationPaths[1].at(index));
  tmp3 = runtime.safeCall(Portfolio2.allocationPaths[2].at(index));
  return globalThis.Object.freeze([
    tmp,
    tmp1[3],
    tmp2[3],
    tmp3[3]
  ])
});
lambda7 = (undefined, function (Portfolio2, index) {
  let tmp, tmp1, tmp2, tmp3;
  tmp = runtime.safeCall(Portfolio2.monthNumbers.at(index));
  tmp1 = runtime.safeCall(Portfolio2.allocationPaths[0].at(index));
  tmp2 = runtime.safeCall(Portfolio2.allocationPaths[1].at(index));
  tmp3 = runtime.safeCall(Portfolio2.allocationPaths[2].at(index));
  return globalThis.Object.freeze([
    tmp,
    tmp1[4],
    tmp2[4],
    tmp3[4]
  ])
});
lambda8 = (undefined, function (Portfolio2, index) {
  return Portfolio2.endingRow(index)
});
(class Portfolio {
  static {
    Portfolio1 = this
  }
  static {
    let tmp, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29, tmp30, tmp31, tmp32, tmp33, tmp34, tmp35, tmp36, tmp37, tmp38, tmp39, tmp40, tmp41, tmp42, tmp43, tmp44, tmp45, tmp46, tmp47, tmp48, tmp49, tmp50, tmp51, tmp52, tmp53, tmp54, tmp55, tmp56, tmp57, tmp58, lambda$here, lambda$here1, lambda$here2, lambda$here3, lambda$here4, inlinedVal, inlinedVal1, inlinedVal2, inlinedVal3, inlinedVal4, rows, inlinedVal5, sourceTable, headers, inlinedVal6, sourceTable1, headers1, inlinedVal7, sourceTable2, headers2, inlinedVal8, sourceTable3, inlinedVal9, sourceTable4, yColumns, inlinedVal10, sourceTable5, yColumns1, inlinedVal11;
    tmp = globalThis.Object.freeze([
      1,
      3.2,
      0.7
    ]);
    tmp1 = - 4.5;
    tmp2 = globalThis.Object.freeze([
      2,
      tmp1,
      0.4
    ]);
    tmp3 = - 6.0;
    tmp4 = - 0.8;
    tmp5 = globalThis.Object.freeze([
      3,
      tmp3,
      tmp4
    ]);
    tmp6 = globalThis.Object.freeze([
      4,
      2.4,
      0.5
    ]);
    tmp7 = globalThis.Object.freeze([
      5,
      4.6,
      0.9
    ]);
    tmp8 = globalThis.Object.freeze([
      6,
      1.1,
      0.3
    ]);
    tmp9 = - 3.7;
    tmp10 = - 0.4;
    tmp11 = globalThis.Object.freeze([
      7,
      tmp9,
      tmp10
    ]);
    tmp12 = globalThis.Object.freeze([
      8,
      5.2,
      1.0
    ]);
    tmp13 = globalThis.Object.freeze([
      9,
      2.8,
      0.6
    ]);
    tmp14 = - 1.9;
    tmp15 = globalThis.Object.freeze([
      10,
      tmp14,
      0.2
    ]);
    tmp16 = globalThis.Object.freeze([
      11,
      4.1,
      0.8
    ]);
    tmp17 = globalThis.Object.freeze([
      12,
      2.6,
      0.4
    ]);
    tmp18 = - 5.4;
    tmp19 = - 0.6;
    tmp20 = globalThis.Object.freeze([
      13,
      tmp18,
      tmp19
    ]);
    tmp21 = - 2.2;
    tmp22 = globalThis.Object.freeze([
      14,
      tmp21,
      0.1
    ]);
    tmp23 = globalThis.Object.freeze([
      15,
      3.9,
      0.7
    ]);
    tmp24 = globalThis.Object.freeze([
      16,
      4.7,
      0.5
    ]);
    tmp25 = globalThis.Object.freeze([
      17,
      1.5,
      0.4
    ]);
    tmp26 = globalThis.Object.freeze([
      18,
      2.3,
      0.6
    ]);
    tmp27 = globalThis.Object.freeze([
      tmp,
      tmp2,
      tmp5,
      tmp6,
      tmp7,
      tmp8,
      tmp11,
      tmp12,
      tmp13,
      tmp15,
      tmp16,
      tmp17,
      tmp20,
      tmp22,
      tmp23,
      tmp24,
      tmp25,
      tmp26
    ]);
    Portfolio.monthlyAssetReturnsPercent = tmp27;
    Portfolio.initialCapitalUsd = 100000;
    Portfolio.defensiveEquityWeight = 0.2;
    Portfolio.balancedEquityWeight = 0.6;
    Portfolio.growthEquityWeight = 0.8;
    Portfolio.monthlyCostPercent = 0;
    Portfolio.displayDecimals = 2;
    tmp28 = 1 - Portfolio.defensiveEquityWeight;
    tmp29 = globalThis.Object.freeze([
      "Defensive",
      Portfolio.defensiveEquityWeight,
      tmp28
    ]);
    tmp30 = 1 - Portfolio.balancedEquityWeight;
    tmp31 = globalThis.Object.freeze([
      "Balanced",
      Portfolio.balancedEquityWeight,
      tmp30
    ]);
    tmp32 = 1 - Portfolio.growthEquityWeight;
    tmp33 = globalThis.Object.freeze([
      "Growth",
      Portfolio.growthEquityWeight,
      tmp32
    ]);
    tmp34 = globalThis.Object.freeze([
      tmp29,
      tmp31,
      tmp33
    ]);
    Portfolio.allocations = tmp34;
    tmp35 = globalThis.Object.freeze([
      0,
      1,
      2
    ]);
    Portfolio.allocationIndexes = tmp35;
    lambda$here = lambda$4(Portfolio);
    tmp36 = runtime.safeCall(Portfolio.allocations.map(lambda$here));
    Portfolio.allocationPaths = tmp36;
    tmp37 = runtime.safeCall(Portfolio.monthlyAssetReturnsPercent.map(lambda3));
    tmp38 = globalThis.Object.freeze([
      0,
      ...tmp37
    ]);
    Portfolio.monthNumbers = tmp38;
    tmp39 = Portfolio.monthIndexes(Portfolio.monthlyAssetReturnsPercent.length);
    Portfolio.pathIndexes = tmp39;
    tmp40 = globalThis.Object.freeze([
      "Month",
      Portfolio.allocations[0][0],
      Portfolio.allocations[1][0],
      Portfolio.allocations[2][0]
    ]);
    Portfolio.comparisonHeaders = tmp40;
    tmp41 = globalThis.Object.freeze([
      Portfolio.allocations[0][0],
      Portfolio.allocations[1][0],
      Portfolio.allocations[2][0]
    ]);
    Portfolio.lineColumns = tmp41;
    inlinedVal = globalThis.Object.freeze([
      "text",
      "c03-disclosure",
      "Synthetic illustrative portfolio demo",
      "These monthly returns are invented educational inputs, not live market data, historical observations, forecasts, or investment advice. Two documents reuse one shared input series and calculation module."
    ]);
    Portfolio.disclosure = inlinedVal;
    inlinedVal1 = globalThis.Object.freeze([
      "text",
      "c03-method",
      "Method and units",
      "Weights are fixed targets and restored at the start of every month, not buy-and-hold drifting weights. Returns are monthly total-return percentages with reinvestment assumed; net return is equity weight times equity return plus bond weight times bond return minus monthlyCostPercent. Wealth compounds without intermediate rounding. Cumulative return (%) = 100 * (wealth / initial capital - 1). Drawdown (%) = 100 * (wealth / running peak - 1), with month 0 included in the peak. Maximum drawdown is the most negative drawdown, not an absolute loss amount. No taxes, leverage, deposits, withdrawals, or additional trading frictions are modeled. In the combined Studio workspace, green assumption and asset-return cells are editable; editing one patches this shared Portfolio.mls module, rebuilds and refreshes both Analysis and Summary."
    ]);
    Portfolio.method = inlinedVal1;
    inlinedVal2 = globalThis.Object.freeze([
      "text",
      "c03-summary-note",
      "Manager brief: illustrative, not a recommendation",
      "Synthetic monthly total returns; three fully invested equity/bond allocations, rebalanced monthly and compounded. The shared assumptions define initial capital and a constant monthly cost. Drawdowns include the initial capital peak; figures are rounded only for display. Analysis.mls contains the full source tables and methodology. The same green Portfolio cells can be edited from either document; both open views rebuild from the shared module."
    ]);
    Portfolio.summaryNote = inlinedVal2;
    tmp42 = globalThis.Object.freeze([
      "Parameter",
      "Value",
      "Unit / meaning"
    ]);
    tmp43 = globalThis.Object.freeze([
      "initialCapitalUsd",
      Portfolio.initialCapitalUsd,
      "USD, positive"
    ]);
    tmp44 = globalThis.Object.freeze([
      "defensiveEquityWeight",
      Portfolio.defensiveEquityWeight,
      "Equity fraction, 0-1; bond weight is its complement"
    ]);
    tmp45 = globalThis.Object.freeze([
      "balancedEquityWeight",
      Portfolio.balancedEquityWeight,
      "Equity fraction, 0-1; bond weight is its complement"
    ]);
    tmp46 = globalThis.Object.freeze([
      "growthEquityWeight",
      Portfolio.growthEquityWeight,
      "Equity fraction, 0-1; bond weight is its complement"
    ]);
    tmp47 = globalThis.Object.freeze([
      "monthlyCostPercent",
      Portfolio.monthlyCostPercent,
      "Monthly return percentage points"
    ]);
    tmp48 = globalThis.Object.freeze([
      "displayDecimals",
      Portfolio.displayDecimals,
      "Displayed decimal places"
    ]);
    tmp49 = globalThis.Object.freeze([
      "months",
      Portfolio.monthlyAssetReturnsPercent.length,
      "Sequential synthetic months"
    ]);
    tmp50 = globalThis.Object.freeze([
      tmp43,
      tmp44,
      tmp45,
      tmp46,
      tmp47,
      tmp48,
      tmp49
    ]);
    inlinedVal3 = globalThis.Object.freeze([
      "table",
      "c03-assumptions",
      "Editable assumptions (green cells patch this module)",
      tmp42,
      tmp50
    ]);
    Portfolio.assumptionsTable = inlinedVal3;
    tmp51 = globalThis.Object.freeze([
      "Allocation",
      "Equity weight (%)",
      "Bond weight (%)"
    ]);
    tmp52 = runtime.safeCall(Portfolio.allocations.map(lambda4));
    inlinedVal4 = globalThis.Object.freeze([
      "table",
      "c03-allocations",
      "Fixed target allocations (monthly rebalancing)",
      tmp51,
      tmp52
    ]);
    Portfolio.allocationTable = inlinedVal4;
    tmp53 = globalThis.Object.freeze([
      "Month",
      "Equity (%)",
      "Bond (%)"
    ]);
    rows = Portfolio.monthlyAssetReturnsPercent;
    inlinedVal5 = globalThis.Object.freeze([
      "table",
      "c03-asset-returns",
      "Shared synthetic monthly asset returns (%)",
      tmp53,
      rows
    ]);
    Portfolio.assetReturnsTable = inlinedVal5;
    lambda$here1 = lambda$3(Portfolio);
    tmp54 = runtime.safeCall(Portfolio.monthlyAssetReturnsPercent.map(lambda$here1));
    sourceTable = Portfolio.assetReturnsTable;
    headers = Portfolio.comparisonHeaders;
    inlinedVal6 = globalThis.Object.freeze([
      "derived",
      "c03-portfolio-returns",
      "Net monthly portfolio returns (%)",
      headers,
      tmp54,
      sourceTable
    ]);
    Portfolio.portfolioReturnsTable = inlinedVal6;
    lambda$here2 = lambda$2(Portfolio);
    tmp55 = runtime.safeCall(Portfolio.pathIndexes.map(lambda$here2));
    sourceTable1 = Portfolio.portfolioReturnsTable;
    headers1 = Portfolio.comparisonHeaders;
    inlinedVal7 = globalThis.Object.freeze([
      "derived",
      "c03-cumulative-returns",
      "Compounded cumulative returns (%) \u2014 month 0 is the baseline",
      headers1,
      tmp55,
      sourceTable1
    ]);
    Portfolio.cumulativeReturnsTable = inlinedVal7;
    lambda$here3 = lambda$1(Portfolio);
    tmp56 = runtime.safeCall(Portfolio.pathIndexes.map(lambda$here3));
    sourceTable2 = Portfolio.cumulativeReturnsTable;
    headers2 = Portfolio.comparisonHeaders;
    inlinedVal8 = globalThis.Object.freeze([
      "derived",
      "c03-drawdowns",
      "Drawdowns from running peak (%) \u2014 negative is below peak",
      headers2,
      tmp56,
      sourceTable2
    ]);
    Portfolio.drawdownTable = inlinedVal8;
    tmp57 = globalThis.Object.freeze([
      "Allocation",
      "Equity (%)",
      "Bond (%)",
      "Ending value (USD)",
      "Cumulative return (%)",
      "Maximum drawdown (%)"
    ]);
    lambda$here4 = lambda$(Portfolio);
    tmp58 = runtime.safeCall(Portfolio.allocationIndexes.map(lambda$here4));
    sourceTable3 = Portfolio.drawdownTable;
    inlinedVal9 = globalThis.Object.freeze([
      "derived",
      "c03-ending-figures",
      "Ending figures \u2014 same shared calculations in both documents",
      tmp57,
      tmp58,
      sourceTable3
    ]);
    Portfolio.endingFiguresTable = inlinedVal9;
    sourceTable4 = Portfolio.cumulativeReturnsTable;
    yColumns = Portfolio.lineColumns;
    inlinedVal10 = globalThis.Object.freeze([
      "line",
      "c03-cumulative-chart",
      "Cumulative return (%) \u2014 three allocation overlay",
      sourceTable4,
      "Month",
      yColumns
    ]);
    Portfolio.cumulativeChart = inlinedVal10;
    sourceTable5 = Portfolio.drawdownTable;
    yColumns1 = Portfolio.lineColumns;
    inlinedVal11 = globalThis.Object.freeze([
      "line",
      "c03-drawdown-chart",
      "Drawdown (%) \u2014 three allocation overlay",
      sourceTable5,
      "Month",
      yColumns1
    ]);
    Portfolio.drawdownChart = inlinedVal11;
  }
  static roundDisplay(value) {
    let tmp, tmp1, tmp2, tmp3;
    tmp = runtime.safeCall(globalThis.Math.pow(10, Portfolio.displayDecimals));
    tmp1 = value * tmp;
    tmp2 = runtime.safeCall(globalThis.Math.round(tmp1));
    tmp3 = runtime.safeCall(globalThis.Math.pow(10, Portfolio.displayDecimals));
    return tmp2 / tmp3
  }
  static monthlyPortfolioPercent(row, allocation) {
    let tmp, tmp1, tmp2;
    tmp = row[1] * allocation[1];
    tmp1 = row[2] * allocation[2];
    tmp2 = tmp + tmp1;
    return tmp2 - Portfolio.monthlyCostPercent
  }
  static nextWealth(previous, row, allocation) {
    let tmp, tmp1, tmp2;
    tmp = Portfolio.monthlyPortfolioPercent(row, allocation);
    tmp1 = tmp / 100;
    tmp2 = 1 + tmp1;
    return previous[1] * tmp2
  }
  static runningPeak(previous, wealth) {
    let scrut;
    scrut = wealth > previous[2];
    if (scrut === true) {
      return wealth
    }
    return previous[2];
  }
  static makeState(month, wealth, peak) {
    let tmp, tmp1, tmp2, tmp3, tmp4, tmp5;
    tmp = wealth / Portfolio.initialCapitalUsd;
    tmp1 = tmp - 1;
    tmp2 = 100 * tmp1;
    tmp3 = wealth / peak;
    tmp4 = tmp3 - 1;
    tmp5 = 100 * tmp4;
    return globalThis.Object.freeze([
      month,
      wealth,
      peak,
      tmp2,
      tmp5
    ])
  }
  static advance(previous, row, allocation) {
    let tmp, tmp1, tmp2;
    tmp = Portfolio.nextWealth(previous, row, allocation);
    tmp1 = Portfolio.nextWealth(previous, row, allocation);
    tmp2 = Portfolio.runningPeak(previous, tmp1);
    return Portfolio.makeState(row[0], tmp, tmp2)
  }
  static simulate(allocation) {
    let tmp, tmp1, lambda$here;
    tmp = globalThis.Object.freeze([
      0,
      Portfolio.initialCapitalUsd,
      Portfolio.initialCapitalUsd,
      0,
      0
    ]);
    tmp1 = globalThis.Object.freeze([
      tmp
    ]);
    lambda$here = lambda$5(Portfolio, allocation);
    return runtime.safeCall(Portfolio.monthlyAssetReturnsPercent.reduce(lambda$here, tmp1))
  }
  static monthlyComparisonRow(row) {
    let tmp, tmp1, tmp2, tmp3, tmp4, tmp5;
    tmp = Portfolio.monthlyPortfolioPercent(row, Portfolio.allocations[0]);
    tmp1 = Portfolio.roundDisplay(tmp);
    tmp2 = Portfolio.monthlyPortfolioPercent(row, Portfolio.allocations[1]);
    tmp3 = Portfolio.roundDisplay(tmp2);
    tmp4 = Portfolio.monthlyPortfolioPercent(row, Portfolio.allocations[2]);
    tmp5 = Portfolio.roundDisplay(tmp4);
    return globalThis.Object.freeze([
      row[0],
      tmp1,
      tmp3,
      tmp5
    ])
  }
  static cumulativeComparisonRow(index) {
    let tmp, tmp1, tmp2, tmp3;
    tmp = runtime.safeCall(Portfolio.monthNumbers.at(index));
    tmp1 = runtime.safeCall(Portfolio.allocationPaths[0].at(index));
    tmp2 = runtime.safeCall(Portfolio.allocationPaths[1].at(index));
    tmp3 = runtime.safeCall(Portfolio.allocationPaths[2].at(index));
    return globalThis.Object.freeze([
      tmp,
      tmp1[3],
      tmp2[3],
      tmp3[3]
    ])
  }
  static drawdownComparisonRow(index) {
    let tmp, tmp1, tmp2, tmp3;
    tmp = runtime.safeCall(Portfolio.monthNumbers.at(index));
    tmp1 = runtime.safeCall(Portfolio.allocationPaths[0].at(index));
    tmp2 = runtime.safeCall(Portfolio.allocationPaths[1].at(index));
    tmp3 = runtime.safeCall(Portfolio.allocationPaths[2].at(index));
    return globalThis.Object.freeze([
      tmp,
      tmp1[4],
      tmp2[4],
      tmp3[4]
    ])
  }
  static monthIndexes(n) {
    let scrut, tmp, tmp1;
    scrut = n <= 0;
    if (scrut === true) {
      return globalThis.Object.freeze([
        0
      ])
    }
    tmp = n - 1;
    tmp1 = Portfolio.monthIndexes(tmp);
    return globalThis.Object.freeze([
      ...tmp1,
      n
    ]);
  }
  static worstDrawdownPercent(path) {
    return runtime.safeCall(path.reduce(lambda1, 0))
  }
  static endingRow(index) {
    let tmp, tmp1, tmp2, tmp3, tmp4, tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, tmp13;
    tmp = runtime.safeCall(Portfolio.allocations.at(index));
    tmp1 = runtime.safeCall(Portfolio.allocations.at(index));
    tmp2 = 100 * tmp1[1];
    tmp3 = runtime.safeCall(Portfolio.allocations.at(index));
    tmp4 = 100 * tmp3[2];
    tmp5 = runtime.safeCall(Portfolio.allocationPaths.at(index));
    tmp6 = runtime.safeCall(tmp5.at(-1));
    tmp7 = Portfolio.roundDisplay(tmp6[1]);
    tmp8 = runtime.safeCall(Portfolio.allocationPaths.at(index));
    tmp9 = runtime.safeCall(tmp8.at(-1));
    tmp10 = Portfolio.roundDisplay(tmp9[3]);
    tmp11 = runtime.safeCall(Portfolio.allocationPaths.at(index));
    tmp12 = Portfolio.worstDrawdownPercent(tmp11);
    tmp13 = Portfolio.roundDisplay(tmp12);
    return globalThis.Object.freeze([
      tmp[0],
      tmp2,
      tmp4,
      tmp7,
      tmp10,
      tmp13
    ])
  }
  toString() { return runtime.render(this); }
  static [definitionMetadata] = ["class", "Portfolio"];
});
export { Portfolio1 as _$_modulePrivate_$_Portfolio };
export { lambda as _$_modulePrivate_$_lambda };
export { lambda1 as _$_modulePrivate_$_lambda1 };
export { lambda2 as _$_modulePrivate_$_lambda2 };
export { lambda3 as _$_modulePrivate_$_lambda3 };
export { lambda4 as _$_modulePrivate_$_lambda4 };
export { lambda5 as _$_modulePrivate_$_lambda5 };
export { lambda6 as _$_modulePrivate_$_lambda6 };
export { lambda7 as _$_modulePrivate_$_lambda7 };
export { lambda8 as _$_modulePrivate_$_lambda8 };
export { lambda$ as _$_modulePrivate_$_lambda$ };
export { lambda$1 as _$_modulePrivate_$_lambda$1 };
export { lambda$2 as _$_modulePrivate_$_lambda$2 };
export { lambda$3 as _$_modulePrivate_$_lambda$3 };
export { lambda$4 as _$_modulePrivate_$_lambda$4 };
export { lambda$5 as _$_modulePrivate_$_lambda$5 };
let Portfolio = Portfolio1; export default Portfolio;
