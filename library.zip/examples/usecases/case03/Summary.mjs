const definitionMetadata = globalThis.Symbol.for("mlscript.definitionMetadata");
const prettyPrint = globalThis.Symbol.for("mlscript.prettyPrint");
import runtime from "file:///c:/Users/ytoh9/.vscode/extensions/mlscript-studio.mlscript-studio-0.7.1/runtime/std/Runtime.mjs";
import Studio from "file:///c:/Users/ytoh9/OneDrive/%EB%B0%94%ED%83%95%20%ED%99%94%EB%A9%B4/mlscropt%200.7.1/library/Studio.mjs";
import Portfolio from "file:///c:/Users/ytoh9/OneDrive/%EB%B0%94%ED%83%95%20%ED%99%94%EB%A9%B4/mlscropt%200.7.1/examples/usecases/case03/shared/Portfolio.mjs";
import Render from "file:///c:/Users/ytoh9/OneDrive/%EB%B0%94%ED%83%95%20%ED%99%94%EB%A9%B4/mlscropt%200.7.1/library/Render.mjs";
let Summary1;
(class Summary {
  static {
    Summary1 = this
  }
  static {
    let tmp, tmp1, tmp2, inlinedVal, inlinedVal1, root, order, inlinedVal2, root1, order1, inlinedVal3;
    tmp = globalThis.Object.freeze([
      Portfolio.cumulativeChart,
      Portfolio.endingFiguresTable
    ]);
    inlinedVal = globalThis.Object.freeze([
      "group",
      "c03-summary-performance",
      "Cumulative performance and ending figures",
      tmp
    ]);
    Summary.performance = inlinedVal;
    tmp1 = globalThis.Object.freeze([
      Portfolio.summaryNote,
      Summary.performance
    ]);
    inlinedVal1 = globalThis.Object.freeze([
      "group",
      "c03-summary-report",
      "Portfolio comparison \u2014 manager meeting brief",
      tmp1
    ]);
    Summary.report = inlinedVal1;
    tmp2 = globalThis.Object.freeze([
      "c03-summary-note",
      "c03-cumulative-chart",
      "c03-ending-figures"
    ]);
    Summary.displayOrder = tmp2;
    root = Summary.report;
    order = Summary.displayOrder;
    inlinedVal2 = runtime.safeCall(Render.render(root, order));
    Summary.document = inlinedVal2;
    root1 = Summary.report;
    order1 = Summary.displayOrder;
    inlinedVal3 = runtime.safeCall(Render.model(root1, order1));
    Summary.model = inlinedVal3;
  }
  toString() { return runtime.render(this); }
  static [definitionMetadata] = ["class", "Summary"];
});
export { Summary1 as _$_modulePrivate_$_Summary };
let Summary = Summary1; export default Summary;
