const definitionMetadata = globalThis.Symbol.for("mlscript.definitionMetadata");
const prettyPrint = globalThis.Symbol.for("mlscript.prettyPrint");
import runtime from "file:///c:/Users/ytoh9/.vscode/extensions/mlscript-studio.mlscript-studio-0.7.1/runtime/std/Runtime.mjs";
import Studio from "file:///c:/Users/ytoh9/OneDrive/%EB%B0%94%ED%83%95%20%ED%99%94%EB%A9%B4/mlscropt%200.7.1/library/Studio.mjs";
import Portfolio from "file:///c:/Users/ytoh9/OneDrive/%EB%B0%94%ED%83%95%20%ED%99%94%EB%A9%B4/mlscropt%200.7.1/examples/usecases/case03/shared/Portfolio.mjs";
import Render from "file:///c:/Users/ytoh9/OneDrive/%EB%B0%94%ED%83%95%20%ED%99%94%EB%A9%B4/mlscropt%200.7.1/library/Render.mjs";
let Analysis1;
(class Analysis {
  static {
    Analysis1 = this
  }
  static {
    let tmp, tmp1, tmp2, tmp3, tmp4, tmp5, inlinedVal, inlinedVal1, inlinedVal2, inlinedVal3, inlinedVal4, root, order, inlinedVal5, root1, order1, inlinedVal6;
    tmp = globalThis.Object.freeze([
      Portfolio.disclosure,
      Portfolio.method,
      Portfolio.assumptionsTable,
      Portfolio.allocationTable
    ]);
    inlinedVal = globalThis.Object.freeze([
      "group",
      "c03-analysis-context",
      "Scope and editable assumptions",
      tmp
    ]);
    Analysis.context = inlinedVal;
    tmp1 = globalThis.Object.freeze([
      Portfolio.assetReturnsTable,
      Portfolio.portfolioReturnsTable
    ]);
    inlinedVal1 = globalThis.Object.freeze([
      "group",
      "c03-analysis-monthly",
      "Source returns and derived monthly portfolios",
      tmp1
    ]);
    Analysis.monthlyReturns = inlinedVal1;
    tmp2 = globalThis.Object.freeze([
      Portfolio.cumulativeReturnsTable,
      Portfolio.cumulativeChart
    ]);
    inlinedVal2 = globalThis.Object.freeze([
      "group",
      "c03-analysis-cumulative",
      "Compounding and cumulative performance",
      tmp2
    ]);
    Analysis.cumulative = inlinedVal2;
    tmp3 = globalThis.Object.freeze([
      Portfolio.drawdownTable,
      Portfolio.drawdownChart,
      Portfolio.endingFiguresTable
    ]);
    inlinedVal3 = globalThis.Object.freeze([
      "group",
      "c03-analysis-risk",
      "Running-peak drawdowns and final figures",
      tmp3
    ]);
    Analysis.risk = inlinedVal3;
    tmp4 = globalThis.Object.freeze([
      Analysis.context,
      Analysis.monthlyReturns,
      Analysis.cumulative,
      Analysis.risk
    ]);
    inlinedVal4 = globalThis.Object.freeze([
      "group",
      "c03-analysis-report",
      "Portfolio comparison \u2014 analyst working report",
      tmp4
    ]);
    Analysis.report = inlinedVal4;
    tmp5 = globalThis.Object.freeze([
      "c03-disclosure",
      "c03-method",
      "c03-assumptions",
      "c03-allocations",
      "c03-asset-returns",
      "c03-portfolio-returns",
      "c03-cumulative-returns",
      "c03-cumulative-chart",
      "c03-drawdowns",
      "c03-drawdown-chart",
      "c03-ending-figures"
    ]);
    Analysis.displayOrder = tmp5;
    root = Analysis.report;
    order = Analysis.displayOrder;
    inlinedVal5 = runtime.safeCall(Render.render(root, order));
    Analysis.document = inlinedVal5;
    root1 = Analysis.report;
    order1 = Analysis.displayOrder;
    inlinedVal6 = runtime.safeCall(Render.model(root1, order1));
    Analysis.model = inlinedVal6;
  }
  toString() { return runtime.render(this); }
  static [definitionMetadata] = ["class", "Analysis"];
});
export { Analysis1 as _$_modulePrivate_$_Analysis };
let Analysis = Analysis1; export default Analysis;
