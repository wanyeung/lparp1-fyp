const definitionMetadata = globalThis.Symbol.for("mlscript.definitionMetadata");
const prettyPrint = globalThis.Symbol.for("mlscript.prettyPrint");
import runtime from "file:///c:/Users/ytoh9/.vscode/extensions/mlscript-studio.mlscript-studio-0.7.1/runtime/std/Runtime.mjs";
import Render from "file:///c:/Users/ytoh9/OneDrive/%EB%B0%94%ED%83%95%20%ED%99%94%EB%A9%B4/mlscropt%200.7.1/library/Render.mjs";
let Studio1;
(class Studio {
  static {
    Studio1 = this
  }
  static CreateGroup(id, title, children) {
    return globalThis.Object.freeze([
      "group",
      id,
      title,
      children
    ])
  }
  static CreateCell(id, title, headers, rows) {
    return globalThis.Object.freeze([
      "table",
      id,
      title,
      headers,
      rows
    ])
  }
  static CreatCell(id, title, headers, rows) {
    return Studio.CreateCell(id, title, headers, rows)
  }
  static DeriveCell(id, title, sourceTable, headers, rows) {
    return globalThis.Object.freeze([
      "derived",
      id,
      title,
      headers,
      rows,
      sourceTable
    ])
  }
  static CreateText(id, title, text) {
    return globalThis.Object.freeze([
      "text",
      id,
      title,
      text
    ])
  }
  static BarChart(id, title, sourceTable, x, y) {
    return globalThis.Object.freeze([
      "bar",
      id,
      title,
      sourceTable,
      x,
      y
    ])
  }
  static PieChart(id, title, sourceTable, x, y) {
    return globalThis.Object.freeze([
      "pie",
      id,
      title,
      sourceTable,
      x,
      y
    ])
  }
  static LineChart(id, title, sourceTable, x, yColumns) {
    return globalThis.Object.freeze([
      "line",
      id,
      title,
      sourceTable,
      x,
      yColumns
    ])
  }
  static Display(root) {
    return runtime.safeCall(Render.render(root))
  }
  static Model(root) {
    return runtime.safeCall(Render.model(root))
  }
  static DisplayOrdered(root, order) {
    return runtime.safeCall(Render.render(root, order))
  }
  static ModelOrdered(root, order) {
    return runtime.safeCall(Render.model(root, order))
  }
  toString() { return runtime.render(this); }
  static [definitionMetadata] = ["class", "Studio"];
});
export { Studio1 as _$_modulePrivate_$_Studio };
let Studio = Studio1; export default Studio;
